#include <stdio.h>
#define cj4 collatzConjecture4

int collatzConjecture4(int num)
{
	return (num == 1) ?0:( num%2==0 ? cj4(num/2) + 1 : cj4(3*num+1) + 1 ) ;
}
int main()
{	int input ;
	printf("enter any number :\n");
	scanf("%d",&input);
	input ? (printf("number of steps it took is %d\n",cj4(input))):(printf("enter positive number\n" ));
}
/****DIFFERENT VERSIONS OF COLLATZ ;

int collatzConjecture(int num)
{
    int count = 0 ;
	while(num != 1)
	{
		if(num %2 == 0)
			num/=2;
		else
			num=num*3+1 ;
		count++;
		//printf("%d\t",num);
	}
	//printf("\ncount %d \n",count);
	return count ;
}

int collatzConjecture2(int num)
{
	int count = 0  ;
	while((num != 1)&&++count&&((num % 2 == 0 )? (num = num/2)  : (num = 3* num +1)));
	return count ;
}



*/ 